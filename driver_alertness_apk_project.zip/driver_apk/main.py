"""
Система контроля бдительности водителя — Android-версия (Kivy)
================================================================
Отслеживает лицо и глаза водителя через камеру телефона.
Если глаза не обнаруживаются в области лица дольше порогового
числа кадров (эвристика: закрытые глаза Haar Cascade обычно не находит),
приложение включает вибрацию и звуковой сигнал.

Собирается в APK через Buildozer (см. buildozer.spec и README.md).
"""

import os
import time

import cv2
import numpy as np

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.core.audio import SoundLoader
from kivy.uix.camera import Camera

try:
    from plyer import vibrator
    VIBRATOR_AVAILABLE = True
except Exception:
    VIBRATOR_AVAILABLE = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

# --------------------------- НАСТРОЙКИ ---------------------------
NO_EYES_CONFIRM_FRAMES = 4   # сколько кадров подряд глаза не найдены, прежде чем бить тревогу
SCAN_EVERY_N_FRAMES = 2      # анализировать не каждый кадр (экономия батареи/CPU)
VIBRATE_REPEAT_SECONDS = 1.0 # как часто повторять вибрацию, пока глаза закрыты
# -------------------------------------------------------------------


class DriverAlertnessApp(App):

    def build(self):
        self.face_cascade = cv2.CascadeClassifier(
            os.path.join(ASSETS_DIR, "haarcascade_frontalface_default.xml")
        )
        self.eye_cascade = cv2.CascadeClassifier(
            os.path.join(ASSETS_DIR, "haarcascade_eye.xml")
        )

        self.alarm_sound = SoundLoader.load(os.path.join(ASSETS_DIR, "alarm.wav"))

        self.no_eyes_count = 0
        self.eyes_closed = False
        self.frame_count = 0
        self.last_vibrate_time = 0
        self.running = False

        root = BoxLayout(orientation="vertical")

        self.status_label = Label(
            text="Нажмите «Запустить», чтобы начать",
            size_hint=(1, 0.1),
            font_size="18sp",
        )
        root.add_widget(self.status_label)

        # play=False: камера включится по кнопке, чтобы не тратить батарею зря
        self.camera = Camera(play=False, resolution=(640, 480), size_hint=(1, 0.8))
        root.add_widget(self.camera)

        self.toggle_btn = Button(
            text="Запустить систему",
            size_hint=(1, 0.1),
            font_size="18sp",
        )
        self.toggle_btn.bind(on_press=self.toggle_running)
        root.add_widget(self.toggle_btn)

        return root

    def toggle_running(self, *args):
        if not self.running:
            self.running = True
            self.camera.play = True
            self.toggle_btn.text = "Остановить систему"
            self.status_label.text = "Слежение активно..."
            Clock.schedule_interval(self.process_frame, 1.0 / 15.0)  # ~15 кадров/сек
        else:
            self.running = False
            self.camera.play = False
            self.toggle_btn.text = "Запустить систему"
            self.status_label.text = "Система остановлена"
            self.stop_alarm()
            Clock.unschedule(self.process_frame)

    def process_frame(self, dt):
        if not self.camera.texture:
            return

        self.frame_count += 1
        if self.frame_count % SCAN_EVERY_N_FRAMES != 0:
            return  # пропускаем кадр для экономии ресурсов

        # Получаем пиксели текущего кадра камеры и конвертируем в формат OpenCV
        texture = self.camera.texture
        w, h = texture.size
        pixels = np.frombuffer(texture.pixels, dtype=np.uint8).reshape(h, w, 4)
        frame_bgr = cv2.cvtColor(pixels, cv2.COLOR_RGBA2BGR)
        frame_bgr = cv2.flip(frame_bgr, 0)  # текстура Kivy перевёрнута по вертикали

        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))

        if len(faces) == 0:
            self.status_label.text = "Лицо не найдено"
            self.no_eyes_count = 0
            self.stop_alarm()
            return

        # Берём самое крупное найденное лицо (ближе всего к камере)
        x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
        face_roi_gray = gray[y:y + fh, x:x + fw]

        eyes = self.eye_cascade.detectMultiScale(
            face_roi_gray, scaleFactor=1.1, minNeighbors=6, minSize=(20, 20)
        )

        if len(eyes) >= 1:
            # Глаза найдены -> считаем, что открыты
            self.no_eyes_count = 0
            if self.eyes_closed:
                self.eyes_closed = False
                self.stop_alarm()
            self.status_label.text = f"Глаза открыты (найдено: {len(eyes)})"
        else:
            # Глаза не найдены в области лица -> вероятно закрыты
            self.no_eyes_count += 1
            if self.no_eyes_count >= NO_EYES_CONFIRM_FRAMES:
                if not self.eyes_closed:
                    self.eyes_closed = True
                self.status_label.text = "ГЛАЗА ЗАКРЫТЫ! ПРОСНИТЕСЬ!"
                self.trigger_alarm()
            else:
                self.status_label.text = f"Проверка... ({self.no_eyes_count}/{NO_EYES_CONFIRM_FRAMES})"

    def trigger_alarm(self):
        now = time.time()

        if VIBRATOR_AVAILABLE:
            if now - self.last_vibrate_time >= VIBRATE_REPEAT_SECONDS:
                try:
                    vibrator.vibrate(0.6)  # вибрация 0.6 секунды
                except Exception:
                    pass
                self.last_vibrate_time = now

        if self.alarm_sound and self.alarm_sound.state != "play":
            self.alarm_sound.loop = True
            self.alarm_sound.play()

    def stop_alarm(self):
        if self.alarm_sound and self.alarm_sound.state == "play":
            self.alarm_sound.stop()
        if VIBRATOR_AVAILABLE:
            try:
                vibrator.cancel()
            except Exception:
                pass


if __name__ == "__main__":
    DriverAlertnessApp().run()
