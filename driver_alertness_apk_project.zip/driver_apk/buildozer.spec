[app]
title = Driver Alertness
package.name = driveralertness
package.domain = org.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,xml,wav
source.include_patterns = assets/*

version = 1.0

# Зависимости, которые Buildozer соберёт под Android
requirements = python3,kivy==2.3.0,opencv-python,numpy,plyer

orientation = portrait
fullscreen = 0

# Разрешения Android
android.permissions = CAMERA,VIBRATE,INTERNET

# API/архитектуры
android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a

# Иконка/сплэш (опционально, можно добавить свои файлы позже)
# icon.filename = %(source.dir)s/assets/icon.png
# presplash.filename = %(source.dir)s/assets/presplash.png

[buildozer]
log_level = 2
warn_on_root = 1
